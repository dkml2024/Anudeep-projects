package org.anudeep.EmployeeMngntSystem.service;

import org.anudeep.EmployeeMngntSystem.Dao.AdminDao;

import org.anudeep.EmployeeMngntSystem.Dao.AdminDaoIMPL;
import org.anudeep.EmployeeMngntSystem.entity.Admin;



public class AdminService {
	private AdminDao adminDao;
	public AdminService()
	{
		adminDao =new AdminDaoIMPL();
	}
 public boolean login(String adminname,String password)
{
	Admin admin=adminDao.findByAdminname(adminname);
  return admin!=null&&admin.getPassword().equals(password);
	
}
public void register(String adminname,String password)
{
	Admin admin=new Admin();
	admin.setAdminname(adminname);
	admin.setPassword(password);
    adminDao.save(admin);
	
}

}

