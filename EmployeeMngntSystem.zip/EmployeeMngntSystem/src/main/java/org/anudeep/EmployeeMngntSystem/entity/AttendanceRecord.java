package org.anudeep.EmployeeMngntSystem.entity;

//import javax.validation.constraints.NotEmpty;
//import javax.validation.constraints.Size;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;



@Entity
public class AttendanceRecord {
	
	@Id //indicate primary key

	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private int attendanceId;
	
	@Column(length =20,nullable =false)
	
	private String ename;
	
	
	@Column(length =20,nullable =false)
	
	 private boolean isAbsent;
   
	
	
    private double hoursWorked;

	
	
    public AttendanceRecord() {
	}

	// Constructor
    public AttendanceRecord(int attendanceId, int employeeId,  boolean isAbsent, double hoursWorked) {
    
        this.attendanceId = attendanceId;
        
       
        this.isAbsent = isAbsent;
      
        this.hoursWorked = hoursWorked;
    }

    // Getters and Setters
    public int getAttendanceId() {
        return attendanceId;
    }

    public void setAttendanceId(int attendanceId) {
        this.attendanceId = attendanceId;
    }

   
 public boolean getisAbsent() {
        return isAbsent;
    }

    public void setAbsent(boolean absent) {
        isAbsent = absent;
    }

   public double getHoursWorked() {
        return hoursWorked;
    }

    public void setHoursWorked(double hoursWorked) {
        this.hoursWorked = hoursWorked;
    }

    

}
