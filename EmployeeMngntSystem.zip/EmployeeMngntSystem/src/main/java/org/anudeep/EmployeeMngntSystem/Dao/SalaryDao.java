package org.anudeep.EmployeeMngntSystem.Dao;


import org.anudeep.EmployeeMngntSystem.entity.Salary;

public interface SalaryDao {

	Salary createSalary(Salary Salary);	
	Salary getSalary(String SalaryID);

	
}
