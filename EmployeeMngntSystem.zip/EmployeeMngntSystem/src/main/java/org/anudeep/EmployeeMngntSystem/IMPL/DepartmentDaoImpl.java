package org.anudeep.EmployeeMngntSystem.IMPL;

import org.anudeep.EmployeeMngntSystem.Dao.DepartmentDao;
import org.anudeep.EmployeeMngntSystem.entity.Department;

import java.util.ArrayList;
import java.util.List;

public class DepartmentDaoImpl implements DepartmentDao {
    private List<Department> departments;

    // Constructor to initialize the list
    public DepartmentDaoImpl() {
        this.departments = new ArrayList<>();
    }

    @Override
    public Department createDepartment(Department department) {
        // Add the department to the list
        departments.add(department);
        return department; // Return the added department
    }

    @Override
    public Department getDepartment(String departmentID) {
        // Search for the department by departmentID
        for (Department dept : departments) {
          //  if (dept.getDepartmentID().equals(departmentID)) 
                return dept; // Return the found department
            }
       
        return null; // Return null if not found
    }
}