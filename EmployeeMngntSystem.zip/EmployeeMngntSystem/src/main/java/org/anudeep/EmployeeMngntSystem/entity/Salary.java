package org.anudeep.EmployeeMngntSystem.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity

public class Salary {

	@Id //indicate primary key
	
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private int SalaryId;
	@Column(length =20,nullable =false)
	
	private double baseSalary;
    private double bonus;
   

    // Constructor
    
    public Salary() 
    {}

     public Salary(double baseSalary, double bonus, double deductions, double allowances) {
        this.baseSalary = baseSalary;
        this.bonus = bonus;
        this. SalaryId =  SalaryId;
    }
	// Getters and Setters
    public double getBaseSalary() {
       // return baseSalary;
        return  SalaryId;
        
    }

    public void setBaseSalary(double baseSalary) {
        this.baseSalary = baseSalary;
        this. SalaryId =  SalaryId;
    }

    public double getBonus() {
        return bonus;
    }

    public void setBonus(double bonus) {
        this.bonus = bonus;

	
    }
	
	
}
