package org.anudeep.EmployeeMngntSystem.Dao;

import org.anudeep.EmployeeMngntSystem.entity.Admin;


public interface AdminDao {
	
		Admin findByAdminname(String adminname);
		void save(Admin admin);
		
		
	}
	
