package org.anudeep.EmployeeMngntSystem.IMPL;


import org.anudeep.EmployeeMngntSystem.Dao.EmployeeRoleDao;
import org.anudeep.EmployeeMngntSystem.entity.EmployeeRole;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class EmployeeRoleDaoIMPL implements EmployeeRoleDao {

    private final SessionFactory sessionFactory;

    public EmployeeRoleDaoIMPL(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    @Override
    public EmployeeRole createEmployeeRole(EmployeeRole employeeRole) {
        Transaction transaction = null;
        try (Session session = sessionFactory.openSession()) {
            transaction = session.beginTransaction();
            session.save(employeeRole);
            transaction.commit();
            return employeeRole;
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            throw e; // or handle exception as needed
        }
    }

    @Override
    public EmployeeRole getEmployeeRole(String employeeRoleID) {
        try (Session session = sessionFactory.openSession()) {
            return session.get(EmployeeRole.class, employeeRoleID);
        } catch (Exception e) {
            // Handle exception as needed
            e.printStackTrace();
            return null;
        }
    }}
