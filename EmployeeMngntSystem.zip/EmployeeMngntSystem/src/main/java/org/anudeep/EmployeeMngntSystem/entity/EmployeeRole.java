package org.anudeep.EmployeeMngntSystem.entity;

//import javax.validation.constraints.NotEmpty;
//import javax.validation.constraints.Size;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class EmployeeRole {

//	public class Role {
		@Id //indicate primary key
		
		@GeneratedValue(strategy = GenerationType.IDENTITY)
	    private int roleId;
		
		@Column(length =40,nullable =false)
		
	    private String roleName;
		
		
	    private String description;
	    
	 // Constructor
	    
	    public EmployeeRole () 
	    {}
	    public  EmployeeRole(int roleId, String roleName, String description) {
	        this.roleId = roleId;
	        this.roleName = roleName;
	        this.description = description;
	    }

	    // Getters and Setters
	    public int getRoleId() {
	        return roleId;
	    }

	    public void setRoleId(int roleId) {
	        this.roleId = roleId;
	    }

	    public String getRoleName() {
	        return roleName;
	    }

	    public void setRoleName(String roleName) {
	        this.roleName = roleName;
	    }

	    public String getDescription() {
	        return description;
	    }

	    public void setDescription(String description) {
	        this.description = description;
	    }

	  
}
