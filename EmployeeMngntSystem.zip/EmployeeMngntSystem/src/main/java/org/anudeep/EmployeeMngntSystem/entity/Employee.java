package org.anudeep.EmployeeMngntSystem.entity;

//import javax.validation.constraints.NotEmpty;
//import javax.validation.constraints.Size;

import jakarta.persistence.*;

@Entity
public class Employee {


@Id //indicate primary key
@GeneratedValue(strategy = GenerationType.IDENTITY)
private int eid;

@Column(length =40,nullable =false)

private String ename;


@Column(length = 20)

private String sname;

@Column(length =50,nullable =false)

private String eaddr;



public Employee() {
}

public Employee(int EmployeeId, String EmployeeName,String EmployeeSurname,  String EmployeeAddres) 
{

	this.eid = EmployeeId;
	this.ename = EmployeeName;
	this.sname =  EmployeeSurname;
	this.eaddr =  EmployeeAddres;
}

public int getEmployeeId() {
	return eid;
}
public void setHotelId(int EmployeeId) {
	this.eid = EmployeeId;
}

public int getEid() {
	return eid;
}

public void setEid(int eid) {
	this.eid = eid;
}

public String getEname() {
	return ename;
}

public void setEname(String ename) {
	this.ename = ename;
}

public String getSname() {
	return sname;
}

public void setSname(String sname) {
	this.sname = sname;
}

public String getEaddr() {
	return eaddr;
}

public void setEaddr(String eaddr) {
	this.eaddr = eaddr;
}

public Object getPassword() {
	// TODO Auto-generated method stub
	return null;
}
}

