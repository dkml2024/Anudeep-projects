package org.anudeep.EmployeeMngntSystem.entity;

import jakarta.persistence.*;

@Entity

public class Department {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int Departmentid;
	
	@Column(length =20,nullable =false)
	
	private String Departmentname;
	

	
	public Department() {
		
	}
	public Department(int DepartmentId, String Departmentname) 
	{
	
		this.Departmentid = DepartmentId;
		this.Departmentname = Departmentname;
		

	}
	public int getDepartmentid() {
		return Departmentid;
	}
	public void setDepartmentid(int departmentid) {
		Departmentid = departmentid;
	}
	public String getDepartmentname() {
		return Departmentname;
	}
	public void setDepartmentname(String departmentname) {
		Departmentname = departmentname;
	}
	

	
	

}
