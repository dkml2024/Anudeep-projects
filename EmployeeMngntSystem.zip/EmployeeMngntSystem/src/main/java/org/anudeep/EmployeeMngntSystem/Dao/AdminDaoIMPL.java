package org.anudeep.EmployeeMngntSystem.Dao;

import org.anudeep.EmployeeMngntSystem.entity.Admin;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;



  public class AdminDaoIMPL implements  AdminDao {
	
	private SessionFactory sessionFactory ;
	public AdminDaoIMPL()
	{
		sessionFactory=new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();	
	}

	public  Admin findByAdminname(String adminname) {
		Session session=sessionFactory.openSession();
		 Admin  admin=null;
		try
		{
			 admin=session.createQuery("FROM Admin WHERE  adminname=:adminname", Admin.class).setParameter("adminname",  admin).uniqueResult();
			
		}
		finally {
			session.close();
		}
		
		return  admin;
	}

	@SuppressWarnings("deprecation")
	public void save( Admin  admin) {
		Session session=sessionFactory.openSession();
		Transaction transaction=null;
		try
		{
			transaction=session.beginTransaction();
			session.save(admin);
			transaction.commit();
		}
		catch(Exception e)
		{
			if(transaction!=null)
				transaction.rollback();
			e.printStackTrace();
		}
		finally
		{
			session.close();
		}

		
	}

	

}
