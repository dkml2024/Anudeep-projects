package org.anudeep.EmployeeMngntSystem.IMPL;

import org.anudeep.EmployeeMngntSystem.Dao.AttendanceRecordDao;
import org.anudeep.EmployeeMngntSystem.entity.AttendanceRecord;

import java.util.ArrayList;
import java.util.List;

public class AttendanceRecordDaoImpl implements AttendanceRecordDao {
    private List<AttendanceRecord> attendanceRecords;

    // Constructor to initialize the list
    public AttendanceRecordDaoImpl() {
        this.attendanceRecords = new ArrayList<>();
    }

    @Override
    public AttendanceRecord createAttendance(AttendanceRecord attendance) {
        // Add the attendance record to the list
        attendanceRecords.add(attendance);
        return attendance; // Return the added attendance record
    }

    @Override
    public AttendanceRecord getAttendance(String attendanceID) {
        // Search for the attendance record by attendanceID
        for (AttendanceRecord record : attendanceRecords) {
            //if (record.getAttendanceID().equals(attendanceID)) 
                return record; 
                // Return the found attendance record
            }
       
        return null; // Return null if not found
    }
}