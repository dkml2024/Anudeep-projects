package org.anudeep.EmployeeMngntSystem.Dao;

import org.anudeep.EmployeeMngntSystem.entity.AttendanceRecord;

public interface AttendanceRecordDao {
	
	AttendanceRecord createAttendance(AttendanceRecord Attendance);	
	AttendanceRecord getAttendance(String AttendanceID);

	
}
