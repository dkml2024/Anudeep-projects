
package org.anudeep.EmployeeMngntSystem;

import java.util.Scanner;

import org.anudeep.EmployeeMngntSystem.entity.Admin;

import org.anudeep.EmployeeMngntSystem.service.AdminService;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class App 
{
    public static void main( String[] args )
    {
    
    
    	Admin a =new  Admin 	();
    	
    	Scanner sc=new Scanner(System.in);
        while(true)
        {
        	 System.out.println( "1.Login" );
        	 System.out.println( "2.Register" );
        	 System.out.println( "3.Exit" );
        	 System.out.println( "Choose an Option:" );
        	 int option=sc.nextInt();
        	 sc.nextLine();
        	 switch(option)
        	 {
        	 case 1:
        		 System.out.println( "AdminName:" );
        		 String loginAdminname=sc.nextLine();
        		 System.out.println( "Password:" );
        		 String loginPassword=sc.nextLine();
        		 if(loginAdminname.equalsIgnoreCase("dkm"))
        		 {
        			 System.out.println( "Login Successful!!" );
        			 break;
        		 }
        		 else
        		 {
        			 System.out.println( "Login Failed..Kindly check Adminname and Password" );
        		 }
        		 break;
        	 }
    	   a.setId(1); 	
    	   a.setAdminname("dkm");
    	   a.setPassword("dkml1234");
    	   
    	   Configuration con = new Configuration().configure().addAnnotatedClass(Admin.class);
    	   SessionFactory sf = con.buildSessionFactory();
    	   Session session = sf.openSession();
    	   Transaction tx = session.beginTransaction();
    	   session.save(a);
    	   
    	   tx.commit();
        	 }
    }
}