package org.anudeep.EmployeeMngntSystem.IMPL;


import org.anudeep.EmployeeMngntSystem.Dao.ProjectDao;
import org.anudeep.EmployeeMngntSystem.entity.Project;

import java.util.ArrayList;
import java.util.List;

public class ProjectDaoImpl implements ProjectDao {
    private List<Project> projects;

    // Constructor to initialize the list
    public ProjectDaoImpl() {
        this.projects = new ArrayList<>();
    }

    @Override
    public Project createProject(Project project) {
        // Add the project to the list
        projects.add(project);
        return project; // Return the added project
    }

    @Override
    public Project getProject(String projectID) {
        // Search for the project by projectID
        for (Project proj : projects) {
           // if (proj.getProjectID().equals(projectID)) 
        	
                return proj; // Return the found project
            }
     
        return null; // Return null if not found
    }
}