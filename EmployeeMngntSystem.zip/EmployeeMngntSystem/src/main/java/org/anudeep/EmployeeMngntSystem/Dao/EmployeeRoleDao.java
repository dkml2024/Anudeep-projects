package org.anudeep.EmployeeMngntSystem.Dao;

import org.anudeep.EmployeeMngntSystem.entity.EmployeeRole;


public interface EmployeeRoleDao {

	EmployeeRole createEmployeeRole(EmployeeRole EmployeeRole);	
	EmployeeRole getEmployeeRole(String EmployeeRoleID);
	
	
}
