package org.anudeep.EmployeeMngntSystem.Dao;


import org.anudeep.EmployeeMngntSystem.entity.Project;

public interface ProjectDao {

	Project createProject(Project Project);	
	Project getProject(String ProjectID);

	
}
