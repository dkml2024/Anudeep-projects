package org.anudeep.EmployeeMngntSystem.Dao;

import org.anudeep.EmployeeMngntSystem.entity.Department;

public interface DepartmentDao {
	
	Department createDepartment(Department Department);	
	Department getDepartment(String DepartmentID);

}
