package org.anudeep.EmployeeMngntSystem.entity;
//import javax.validation.constraints.NotEmpty;
//import javax.validation.constraints.Size;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Project {

	@Id //indicate primary key
	
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	   private int projectId;
	
	@Column(length =20,nullable =false)
	
	    private String projectName;
	
	    private String projectManager;
	   

	    // Constructor
	    public Project() 
	    {}
	    
	    public Project(int projectId, String projectName, String projectManager) {
	        this.projectId = projectId;
	        this.projectName = projectName;
	        this.projectManager = projectManager;
	       
	    }

		// Getters and Setters
	    public int getProjectId() {
	        return projectId;
	    }

	    public void setProjectId(int projectId) {
	        this.projectId = projectId;
	    }

	    public String getProjectName() {
	        return projectName;
	    }

	    public void setProjectName(String projectName) {
	        this.projectName = projectName;
	    }

	    public String getProjectManager() {
	        return projectManager;
	    }

	    public void setProjectManager(String projectManager) {
	        this.projectManager = projectManager;
	    }

	    
	}
