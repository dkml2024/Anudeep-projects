package org.anudeep.EmployeeMngntSystem.IMPL;


import org.anudeep.EmployeeMngntSystem.Dao.SalaryDao;
import org.anudeep.EmployeeMngntSystem.entity.Salary;

import java.util.ArrayList;
import java.util.List;

public class SalaryDaoImpl implements SalaryDao {
    private List<Salary> salaries;

    // Constructor to initialize the list
    public SalaryDaoImpl() {
        this.salaries = new ArrayList<>();
    }

    @Override
    public Salary createSalary(Salary salary) {
        // Add the salary to the list
        salaries.add(salary);
        return salary; // Return the added salary
    }

    @Override
    public Salary getSalary(String salaryID) {
        // Search for the salary by salaryID
        for (Salary sal : salaries) {
          //  if (sal.getSalaryID().equals(salaryID)) 
                return sal; 
                // Return the found salary
            }
       
        return null;
        // Return null if not found
    }
}